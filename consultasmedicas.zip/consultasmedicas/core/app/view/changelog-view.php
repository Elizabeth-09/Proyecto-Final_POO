<div class="row">
<div class="col-md-12">
<h1>Sistema de Consultas Medicas</h1>
<p>Bienvenido a <b>ConsultasMedicas</b> un Sistema de Consultas Medicas util para consultorios medicos y/o medicos independientes.</p>
<h4>Caracterisiticas:</h4>
<ul>
	<li>Vista del Calendario</li>
	<li>Asociar medicos con Areas Medicas. </li>
	<li>Correcion del Bug al agregar Areas medicas</li>
</ul>
<ul>
	<li>Gestion de Citas</li>
	<li>Gestion de Medicos</li>
	<li>Gestion de Pacientes</li>
	<li>Gestion de Usuarios con Acceso al Sistema</li>
	<li>Historial de Citas por Paciente</li>
	<li>Historial de Citas por Medico</li>
	<li>Buscador avanzado por : Palabra clave, medico, paciente y fecha.</li>
</ul>
</div>
</div>
